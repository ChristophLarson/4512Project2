#include "Objective.h"
#include "Constraint.h"
#include <string>

template <typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<T>& vec)
{
	os << "[";
	for (int i = 0; i < vec.size(); ++i)
	{
		os << vec[i];
		if (i != vec.size() - 1)
			os << ", ";
	}
	os << "]\n";
	return os;
}

double Objective::at(int i)
{
	return zCoeff.at(i);
}

double Objective::back()
{
	return zCoeff.back();
}

int Objective::size()
{
	return zCoeff.size();
}

void Objective::printObjective()
{
	std::cout << zCoeff;
}

 void Objective::printTableau(Constraint c)
{
	std::string offset = "";
	std::cout << std::endl;
	printf(" _________________________________________________________________________________________________________\n");
	printf("|%-5s|%-80s|%-5s|\n", "Basic Var", "                                   All Variables", "RHS (Solution)");
	printf("|%-9s|%-80s|%-14s|\n", "", "", "");

	int numColumns = c.getM();

	switch (numColumns) {
	case 4:
		
			printf("|%-9s|%-80s|%-14s|\n", "", "  z         x1        x2       s1        s2        s3        s4", "");
			offset = "          ";

		break;
	case 3:
		printf("|%-9s|%-80s|%-14s|\n", "", "  z         x1        x2       s1        s2        s3", "     ");


		break;
	case 2:
		printf("|%-9s|%-80s|%-14s|\n", "", "  z         x1        x2       s1        s2", "              ");
		offset = "                              ";


		break;
	case 1:

		if (c.getN() > 2)
		{
			printf("|%-9s|%-80s|%-14s|\n", "", "  z         x1        x2       x3        x4        x5        s1", "");
			offset = "          ";
		}
		else
		{
			printf("|%-9s|%-80s|%-14s|\n", "", "  z         x1        x2       s1", "");
			offset = "                                        ";
		}

		break;
	}

	printf("|%-9s|%-80s|%-14s|\n", "---------", "--------------------------------------------------------------------------------",
		"--------------");
	printf("|%-9s|", "z");

	/* Fill in z row up to RHS*/
	//printf(" ");
	for (int i = 0; i < zCoeff.size() - 1; i++)
	{
		printf("%-8.2f  ", zCoeff.at(i));
	}

	/*
	 Adds RHS value. 
	 */
	printf("%s|%-14.2f|\n",offset.c_str(), zCoeff.back());

	printf("|%-9s|%-80s|%-14s|\n", "---------", "--------------------------------------------------------------------------------",
		"--------------");

	/* Store the constraint coefficient matrix for easy access by the loop
	below. */
	std::vector<std::vector<double>> constraintCoeff = c.getCoeff();


	/* Loop to fill in one row for LHS of each constraint. */
	for (int m = 0; m < c.getM(); m++)
	{
		// First fill the basic var column.
		printf("|%-s%-8d|", "s", m + 1);

		for (int n = 0; n < c.getNumCols() - 1; n++)
		{
			printf("%-8.2f  ", constraintCoeff[m][n]);
		}

		/* Print RHS.*/
		printf("%s|%-14.2f|\n", offset.c_str(), constraintCoeff[m].back());
	}
	printf(" _________________________________________________________________________________________________________\n\n");

}

/* Further parameterized version to change basic var column according to the entering and leaving
variables. */
 void Objective::printTableau(Constraint c, std::vector<int> entering)
 {
	std::string offset = "";
	printf(" _________________________________________________________________________________________________________\n");
	printf("|%-5s|%-80s|%-5s|\n", "Basic Var", "                                   All Variables", "RHS (Solution)");
	printf("|%-9s|%-80s|%-14s|\n", "", "", "");

	int numColumns = c.getM();

	switch (numColumns) {
	case 4:
		printf("|%-9s|%-80s|%-14s|\n", "", "  z         x1        x2       s1        s2        s3        s4", "");
		offset = "          ";

		break;
	case 3:
		printf("|%-9s|%-80s|%-14s|\n", "", "  z         x1        x2       s1        s2        s3", "");


		break;
	case 2:
		printf("|%-9s|%-80s|%-14s|\n", "", "  z         x1        x2       s1        s2", "");
		offset = "                              ";

		break;
	case 1:
		if (c.getN() > 2)
		{
			printf("|%-9s|%-80s|%-14s|\n", "", "  z         x1        x2       x3        x4        x5        s1", "");
			offset = "          ";
		}
		else
		{
			printf("|%-9s|%-80s|%-14s|\n", "", "  z         x1        x2       s1", "");
			offset = "                                        ";
		}
	}

	printf("|%-9s|%-80s|%-14s|\n", "---------", "--------------------------------------------------------------------------------",
		"--------------");
	printf("|%-9s|", "z");

	/* Fill in z row up to RHS*/
	//printf(" ");
	for (int i = 0; i < zCoeff.size() - 1; i++)
	{
		printf("%-8.2f  ", zCoeff.at(i));
	}

	/*
	 Adds RHS value. 
	 */
	printf("%s|%-14.2f|\n", offset.c_str(), zCoeff.back());

	printf("|%-9s|%-80s|%-14s|\n", "---------", "--------------------------------------------------------------------------------",
		"--------------");

	/* Store the constraint coefficient matrix for easy access by the loop
	below. */
	std::vector<std::vector<double>> constraintCoeff = c.getCoeff();


	/* Loop to fill in one row for LHS of each constraint. */
	for (int m = 0; m < c.getM(); m++)
	{
		if (entering.at(m) != 0 ) // True: Row is flagged as leaving
		{
			// Change to the entering variable.
			printf("|%-s%-8d|", "x", entering.at(m));
		}
		else 
		{
			// Keep the slack variable.
			printf("|%-s%-8d|", "s", m + 1);
		}

		for (int n = 0; n < c.getNumCols() - 1; n++)
		{
			printf("%-8.2f  ", constraintCoeff[m][n]);
		}

		/* Print RHS.*/
		printf("%s|%-14.2f|\n", offset.c_str(), constraintCoeff[m].back());
	}
	printf(" _________________________________________________________________________________________________________\n\n");

}

/* Designed such that the user need only enter the coefficients of the objective
function from left to right (ignoring the equal sign). This function will
convert, for example, z = 5X1 + 4X2 to z - 5X1 -4X2 = 0. */

Objective::Objective(std::vector<double> coefficients, Constraint constraint)
{
	this->zCoeff.push_back(1); // Coeff on z will always be 1

	for (int i = 0; i < coefficients.size(); i++)
	{
		this->zCoeff.push_back(coefficients.at(i) * -1);
	}

	for (int i = 0; i < constraint.getM(); i++)
	{
		this->zCoeff.push_back(0); // Add m slack variables, all set to 0.
	}

	this->zCoeff.push_back(0); // Add the RHS, which will always start at 0.
}

/* Use the simplex algorithm to calculate the maximum coordinate for
the objective function. */
void Objective::optimalMinOrMax(int minMax, Constraint& c)
{
	// Counter for tableau labels.
	int i = 1;
	/* 
	The vector's purpose is to maintain a record of the entering and exiting
	variables for the duration of the loop so that the tables are printed
	accordingly.

	The function of this vector best explained with an example:
	[3, 2, 0, 1] would mean that s1 has left the bases and been replaced by x3,
	s2 has left the basis and been replaced by x2, and s4 has left the basis and
	been replaced by x1. */
	std::vector<int> entering = { 0, 0, 0, 0 };

	std::cout << std::endl << "Initial Tableau:" << std::endl;
	printTableau(c);
	std::cout << "Current value of basic variables: (";
	for (int i = 0; i < c.getM(); i++)
	{
		std::cout << c.at(i).back() << ", ";
	}
	std::cout << "\b\b)" << std::endl;

	printf("\nThe current value of Z is %.2f.\n\n", zCoeff.back());

	/*See below */
	double absSum = 0;
	double trueSum = 0;

	/* Sum of absolute values of coefficients. Going to compare to sum of
	true vaule to test if every coefficient is positive. That's how we know we
	have found the optimal soultion. Appears here to first check if any work needs
	to be done. */
	for (int i = 1; i < zCoeff.size(); i++)
	{
		absSum += abs(zCoeff.at(i));
		trueSum += zCoeff.at(i);
	}

	bool subOptimal = false;
	std::string maxOrMin;

	if (minMax == 0)
	{
		subOptimal = (trueSum != -1 * absSum);
		maxOrMin = "minimum";
	}
	else
	{
		subOptimal = (trueSum != absSum);
		maxOrMin = "maximum";
	}
	while (subOptimal) 
	{
		/*  Keeps track of how many iterations. See last lines
		in while loop where some printing is done.
		*/
		i++;

		/*std::cout << zCoeff;
		std::cout << std::endl;*/

		/* Reset these so we can check at the end. */
		absSum = 0;
		trueSum = 0;

		/* Entering-variable column number. Starting at 1 because the 0th
		column is always a column of 0's. See tableau. */
		int pivotCol = 1;

		/* Exiting-variable row number. Start at 0 so that if loop on line
		290 fails, the exiting-variable row is correctly identified as the first
		one. */
		int pivotRow = 0;

		if (minMax == 1)
		{
			/* Entering variable corresponds to:
			//	Most negative coefficient in Objective because maximizing. */

			for (int i = 2; i < zCoeff.size(); i++)
			{
				if (zCoeff.at(i) < zCoeff.at(pivotCol) && (zCoeff.at(i) < 0))
				{
					pivotCol = i; // Pivot column is column of entering-var.

				}
			}
		}
		else
		{
			/* Entering variable corresponds to:
			//	Most positive coefficient in Objective because minimizing. */
			for (int i = 2; i < zCoeff.size(); i++)
				{
					if ((zCoeff.at(i) > 0 > zCoeff.at(pivotCol)) && (zCoeff.at(i) > zCoeff.at(pivotCol)))
					{
						//eVar = coefficients[i];
						pivotCol = i; // Pivot column is column of entering-var.

					}
				}
		}

		/*Test for unbounded FR.
		If all non-basic variables in the pivot column are <= 0, the FR is unbounded.*/
		double colSum = 0;
		for (int i = 0; i < c.getM(); i++)
		{
			colSum += c.at(i, pivotCol);
		}

		if (colSum <= 0)
		{
			printf("\nAll of the non-basic variables in the pivot column, column %d, are <=0. The FR is therefore unbounded.\n\n",
				pivotCol+1);
			break;
		}

		//printf("\nPivot Column: %d \n", pivotCol);

		/* Vector of size equal to number of contraints. For the given row, stores
		the ratio of the RHS to the value of the eVar in that row. See following loop.*/
		std::vector<double> ratios(c.getM());

		/* Loop through each constraint row and store ratio of RHS to pivot column value. */
		for (int i = 0; i < c.getM(); i++)
		{
			
			ratios.at(i) = (double)c.at(i).back() / (double)c.at(i, pivotCol); // ratio of RHS to pivot column.

		}

		/* Identify pivot row as that with the minimum positive ratio of 
		RHS to pivot column element. */

		//int evar = 0;
		for (int i = 1; i < ratios.size(); i++)
		{
			if ((ratios.at(i) > 0) && (ratios.at(i) <= ratios.at(pivotRow)))
			{
				pivotRow = i;
			}

		}
		entering[pivotRow] = pivotCol;

		//printf("\nPivot Row: %d \n", pivotRow);

		/* Divide pivot row by pivot element. Starting at 1st element in each row because
		the 0th element is always a 0. See tableau.*/

		double pivotElement = c.at(pivotRow).at(pivotCol); // Value of pivot element.

		for (int i = 1; i < c.getNumCols(); i++)
		{

			c.setVal(pivotRow, i, ((double)c.at(pivotRow, i) / pivotElement));
		}

		/* Apply rule #2 to z row:
		New row = (current row) - (its piv col coeff)(new piv row). */
		double pivotCoeff = zCoeff.at(pivotCol);
		for (int i = 1; i < zCoeff.size(); i++)
		{
			zCoeff.at(i) = zCoeff.at(i) - pivotCoeff * (double)c.at(pivotRow).at(i);
			
		}


		/* Apply rule #2 to each constraint row:
		New row = (current row) - (its piv col coeff)(new piv row). */
		for (int i = 0; i < c.getM(); i++)
		{
			pivotCoeff = c.at(i).at(pivotCol);
			if(i != pivotRow)
			{ 
				for (int j = 1; j < c.getNumCols(); j++)
				{
					c.setVal(i, j, (c.at(i).at(j) - pivotCoeff * (double)c.at(pivotRow).at(j)));
				}
			}
		}

		/* Sum of absolute values of coefficient. Going to compare to sum of
		true vaule to test if every coefficient is positive. That's how we know we
		have found the optimal soultion. Reset the values for each iteration.
		*/
		
		for (int i = 1; i < zCoeff.size(); i++)
		{
			absSum += abs(zCoeff.at(i));
			trueSum += zCoeff.at(i);
		}

		if (minMax == 0)
		{
			subOptimal = (trueSum != -1 * absSum);
			
		}
		else
		{
			subOptimal = (trueSum != absSum);
		}

		std::cout << "Tableau " << i << std::endl;
		printTableau(c, entering);
		
		std::cout << "Current value of basic variables: (";
		for (int i = 0; i < c.getM(); i++)
		{
			std::cout << c.at(i).back() << ", ";
		}
		std::cout << "\b\b)" << std::endl;

		printf("\nThe current value of Z is %.2f.\n\n", zCoeff.back());

		if (!subOptimal)
		{
			printf("\nThe optimal %s of Z is %.2f.\n\n", maxOrMin.c_str(), zCoeff.back());
		}
	}	
}
	


