#pragma once

#include <vector>
#include "Constraint.h"

template <typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<T>& vec);

class Objective

{
	private:

		std::vector<double> zCoeff;

		/*
		A 0 denotes a minimization problem, and a 1 denotes a maximization.
		problem.

		int maxOrMin;
		*/
		

	public:

		double at(int i);

		double back();

		int size();

		void printObjective();

		void printTableau(Constraint c);

		void printTableau(Constraint c, std::vector<int> entering);

		Objective(std::vector<double> coefficients, Constraint constraint);

		void optimalMinOrMax(int minMax, Constraint& c);

};

