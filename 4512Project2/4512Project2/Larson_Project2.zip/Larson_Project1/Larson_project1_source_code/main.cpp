#include <iostream>
#include <cstdio>
#include <vector>
#include "Constraint.h"
#include "Objective.h"

int main()
{
    //Problem 1

    printf("--------------------PROBLEM 1-------------------- \n");
    std::vector<std::vector<double>> constraints1
    {
        {6, 4, 24},
        {1, 2, 6},
        {-1, 1, 1},
        {0, 1, 2}
    };

    std::vector<double> obj1 = { 5, 4 };

    Constraint c1(4, 2, constraints1);

    Objective o1(obj1, c1);

    o1.optimalMinOrMax(1, c1);


    //Problem 2
    printf("--------------------PROBLEM 2-------------------- \n");
    std::vector<std::vector<double>> constraints2
    {
        {6, 4, 24},
        {1, 2, 6},
        {-1, 1, 1},
        {0, 1, 2}
    };

    std::vector<double> obj2 = { 5, -10 };

    Constraint c2(4, 2, constraints1);

    Objective o2(obj2, c2);

    o2.optimalMinOrMax(0, c2);

    //Problem 3
    printf("--------------------PROBLEM 3-------------------- \n");
    std::vector<std::vector<double>> constraints3
    {
        {6, 4, 24},
        {2, 4, 12},
        {-1, 1, 1},
        {0, 1, 1}

    };

    std::vector<double> obj3 = { 4, 2 };

    Constraint c3(4, 2, constraints3);

    Objective o3(obj3, c3);

    o3.optimalMinOrMax(1, c3);

    //Problem 4
    printf("--------------------PROBLEM 4-------------------- \n");
    std::vector<std::vector<double>> constraints4
    {
        {6, 4, 2, 4, 15, 60}
    };

    std::vector<double> obj4 = { 5, 4, -8, 6, 2 };

    Constraint c4(1, 5, constraints4);

    Objective o4(obj4, c4);

    o4.optimalMinOrMax(1, c4);

    //Problem 5
    printf("--------------------PROBLEM 5-------------------- \n");
    std::vector<std::vector<double>> constraints5
    {
        {2, 2, 8},
        {1, 2, 5}
    };

    std::vector<double> obj5 = { 5, 10 };

    Constraint c5(2, 2, constraints5);

    Objective o5(obj5, c5);

    o5.optimalMinOrMax(1, c5);

     //Problem 6
    printf("--------------------PROBLEM 6-------------------- \n");
    std::vector<std::vector<double>> constraints6
    {
        {2, -5, 8},
        {1, 0, 2}
    };

    std::vector<double> obj6 = { 10, 1 };

    Constraint c6(2, 2, constraints6);

    Objective o6(obj6, c6);

    o6.optimalMinOrMax(1, c6);

    std::cout << "Done!";
    std::getchar();
}